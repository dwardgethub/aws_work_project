import { SSMClient, GetParameterCommand } from '@aws-sdk/client-ssm';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, GetCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';
import { ApiGatewayManagementApiClient, PostToConnectionCommand } from '@aws-sdk/client-apigatewaymanagementapi';

const ssm = new SSMClient({});
const ddb = DynamoDBDocumentClient.from(new DynamoDBClient({}));

let cachedApiKey = null;

async function getApiKey() {
  if (cachedApiKey) return cachedApiKey;
  const result = await ssm.send(new GetParameterCommand({
    Name: '/ttt/anthropic-api-key',
    WithDecryption: true
  }));
  cachedApiKey = result.Parameter.Value;
  return cachedApiKey;
}

const WIN_PATTERNS = [
  [0,1,2],[3,4,5],[6,7,8],
  [0,3,6],[1,4,7],[2,5,8],
  [0,4,8],[2,4,6]
];

function checkWinner(board) {
  for (const [a,b,c] of WIN_PATTERNS) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a], line: [a,b,c] };
    }
  }
  if (board.every(c => c !== '')) return { winner: 'draw', line: [] };
  return null;
}

async function send(apigw, connectionId, data) {
  try {
    await apigw.send(new PostToConnectionCommand({
      ConnectionId: connectionId,
      Data: JSON.stringify(data)
    }));
  } catch(e) {
    console.error('Send failed:', e.message);
  }
}

async function getClaudeMove(board) {
  const apiKey = await getApiKey();

  const display = [0,1,2,3,4,5,6,7,8].map(i =>
    board[i] !== '' ? board[i] : String(i)
  );

  const prompt = `You are playing Tic-Tac-Toe as O. The board uses indices 0-8:
${display[0]} | ${display[1]} | ${display[2]}
---------
${display[3]} | ${display[4]} | ${display[5]}
---------
${display[6]} | ${display[7]} | ${display[8]}

X has already played. It is your turn as O.
The empty cells are: ${board.map((v,i) => v==='' ? i : null).filter(v=>v!==null).join(', ')}.

Respond with ONLY a single digit — the index number of your chosen move. No explanation, no punctuation, just one digit.`;

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 10,
      messages: [{ role: 'user', content: prompt }]
    })
  });

  const data = await response.json();
  const text = data.content?.[0]?.text?.trim();
  const index = parseInt(text, 10);

  if (!isNaN(index) && index >= 0 && index <= 8 && board[index] === '') {
    return index;
  }

  console.warn('Claude returned invalid move:', text, '— using fallback');
  return board.findIndex(c => c === '');
}

export const handler = async (event) => {
  const connectionId = event?.requestContext?.connectionId;
  const domainName   = event?.requestContext?.domainName;
  const stage        = event?.requestContext?.stage;

  if (!connectionId || !domainName || !stage) {
    return { statusCode: 400, body: 'Missing requestContext' };
  }

  const body   = JSON.parse(event.body || '{}');
  const gameId = body.gameId;

  const apigw = new ApiGatewayManagementApiClient({
    endpoint: `https://${domainName}/${stage}`
  });

  const gameResult = await ddb.send(new GetCommand({
    TableName: 'TTT_Games',
    Key: { gameId }
  }));

  const game = gameResult.Item;

  if (!game || game.status !== 'active') {
    await send(apigw, connectionId, { type: 'ERROR', message: 'Game not active.' });
    return { statusCode: 400 };
  }

  let index;
  try {
    index = await getClaudeMove(game.board);
  } catch(e) {
    console.error('Claude API error:', e);
    await send(apigw, connectionId, { type: 'ERROR', message: 'AI is thinking... please try again.' });
    return { statusCode: 500 };
  }

  const newBoard = [...game.board];
  newBoard[index] = 'O';

  const result    = checkWinner(newBoard);
  const newStatus = result ? 'finished' : 'active';

  await ddb.send(new UpdateCommand({
    TableName: 'TTT_Games',
    Key: { gameId },
    UpdateExpression: 'SET board = :b, currentTurn = :t, #s = :s, winner = :w',
    ExpressionAttributeNames: { '#s': 'status' },
    ExpressionAttributeValues: {
      ':b': newBoard,
      ':t': 'X',
      ':s': newStatus,
      ':w': result?.winner || null
    }
  }));

  const broadcast = {
    type: 'MOVE_MADE',
    board: newBoard,
    lastMove: { index, symbol: 'O' },
    currentTurn: 'X',
    winner: result?.winner || null,
    winLine: result?.line || [],
    gameOver: !!result,
    symbol: 'X',
    yourTurn: !result
  };

  await send(apigw, connectionId, broadcast);

  return { statusCode: 200 };
};
